package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import com.infy.exception.InfyAcademyException;

import application.EmailValidator;


public class EmailValidatorTest {
	
	private EmailValidator ev; 

	@BeforeEach
	public void setUp() {
	    ev = new EmailValidator();
	}
	
	@Test
	public void validateEmailIdValidEmailId() throws InfyAcademyException {
		
		boolean actualEmail=ev.validateEmailId("Varsha@123.com");
		boolean expectedValue=false;
		assertEquals(actualEmail,expectedValue);
	}

	@Test
	public void validateEmailIdInvalidEmailId() throws InfyAcademyException {
		boolean actualEmail=ev.validateEmailId("deepak_gurav@varroc.com");
		boolean expectedValue=false;
		assertEquals(actualEmail,expectedValue);
	}

	@Test
	public void validateEmailIdInvalidEmailIdException() throws InfyAcademyException {
		 assertThrows(InfyAcademyException.class,
		            ()->{
		            	
		            	boolean email=ev.validateEmailId(null);
		            });
		
	}
	
	@ParameterizedTest
	@ValueSource(strings = { "rani_red","vrunda_Redekar@ccm.in","deep_gurav","NikhilFadake@gmail.com" })
	public void validateEmailIdParamterizedEmailId(String abc) throws InfyAcademyException {
		assertNotNull(abc);
	}
	
	@AfterEach
	public void teardown() {
	   ev = null;
	}
}
